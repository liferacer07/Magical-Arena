package Swiggy;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlayerTest {

    @Test
    public void testPlayerAlive() {
        Player playerA = new Player(50, 10, 5, "Player A");
        assertTrue(playerA.isAlive(), "Player should be alive with health greater than 0");
    }

    @Test
    public void testPlayerDead() {
        Player playerB = new Player(0, 10, 5, "Player B");
        assertFalse(playerB.isAlive(), "Player should be dead with health equal to 0");
    }

    @Test
    public void testNegativeHealth() {
        try {
            Player playerC = new Player(-5, 10, 5, "Player C");
            fail("Expected IllegalArgumentException due to negative health");
        } catch (IllegalArgumentException e) {
            assertEquals("Health must be between 1 and 100.", e.getMessage());
        }
    }

    @Test
    public void testExcessiveHealth() {
        try {
            Player playerD = new Player(101, 10, 5, "Player D");
            fail("Expected IllegalArgumentException due to health greater than 100");
        } catch (IllegalArgumentException e) {
            assertEquals("Health must be between 1 and 100.", e.getMessage());
        }
    }

    @Test
    public void testInvalidStrength() {
        try {
            Player playerE = new Player(50, 35, 5, "Player E");
            fail("Expected IllegalArgumentException due to strength greater than 30");
        } catch (IllegalArgumentException e) {
            assertEquals("Strength must be between 1 and 30.", e.getMessage());
        }
    }

    @Test
    public void testInvalidAttack() {
        try {
            Player playerF = new Player(50, 10, 40, "Player F");
            fail("Expected IllegalArgumentException due to attack greater than 30");
        } catch (IllegalArgumentException e) {
            assertEquals("Attack must be between 1 and 30.", e.getMessage());
        }
    }

    @Test
    public void testReceiveDamage() {
        Player playerG = new Player(50, 10, 5, "Player G");
        playerG.receiveDamage(10);
        assertEquals(40, playerG.getHealth(), "Player's health should decrease by 10 after taking damage");

        playerG.receiveDamage(100);
        assertEquals(0, playerG.getHealth(), "Player's health should not be less than 0");
    }

    @Test
    public void testCalculateAttackDamage() {
        Player playerH = new Player(50, 10, 5, "Player H");
        int damage = playerH.calculateAttackDamage();
        assertTrue(damage >= 5 && damage <= 30, "Attack damage should be between 5 and 30");
    }

    @Test
    public void testCalculateDefendStrength() {
        Player playerI = new Player(50, 10, 5, "Player I");
        int defendStrength = playerI.calculateDefendStrength();
        assertTrue(defendStrength >= 10 && defendStrength <= 60, "Defend strength should be between 10 and 60");
    }
}
