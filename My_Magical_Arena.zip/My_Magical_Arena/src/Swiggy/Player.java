package Swiggy;

import java.util.Random;

class Player {
    private int health;
    private int strength;
    private int attack;
    private String name;
    private Random random;

    // Constructor to initialize a player with given attributes
    public Player(int health, int strength, int attack, String name) {
        if (health <= 0 || health > 100) {  // Health must be between 1 and 100
            throw new IllegalArgumentException("Health must be between 1 and 100.");
        }
        
        //** Strength and Attack must be between 1 and 30 **//
        if (strength < 1 || strength > 30) {
            throw new IllegalArgumentException("Strength must be between 1 and 30.");
        }
        
        if (attack < 1 || attack > 30) {
            throw new IllegalArgumentException("Attack must be between 1 and 30.");
        }

        this.health = health;
        this.strength = strength;
        this.attack = attack;
        this.name = name;
        this.random = new Random();
    }

    // Method to get the player's current health
    public int getHealth() {
        return health;
    }

    // To get the name of the player
    public String getName() {
        return this.name;
    }

    // Method to check if the player is alive (health > 0)
    public boolean isAlive() {
        return health > 0;
    }

    // Method to apply damage to the player
    public void receiveDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }

    // Method to simulate rolling a six-sided die
    public int rollDice() {
        return random.nextInt(6) + 1; // Roll a 6-sided die
    }

    // Method to calculate the damage inflicted by the player's attack
    public int calculateAttackDamage() {
        int diceValue = rollDice();
        return attack * diceValue;
    }

    // Method to calculate the defense strength of the player
    public int calculateDefendStrength() {
        int diceValue = rollDice();
        return strength * diceValue;
    }
}
