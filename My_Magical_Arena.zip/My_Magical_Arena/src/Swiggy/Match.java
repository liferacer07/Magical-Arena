package Swiggy;

public class Match {
    private Player playerA;
    private Player playerB;

    // Constructor to initialize the match with two players
    public Match(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
    }

    // Method to start the match
    public void start() {
        // Determine the initial attacker and defender based on their health
        Player attacker = (playerA.getHealth() <= playerB.getHealth()) ? playerA : playerB;
        Player defender = (attacker == playerA) ? playerB : playerA;

        System.out.println("Starting the match between " + this.playerA.getName() + " - " + this.playerB.getName());
        System.out.println(attacker.getName() + " will start with attacking");

        int rounds = 0;

        while (playerA.isAlive() && playerB.isAlive()) {
            System.out.println("\nRound: " + ++rounds);
            attack(attacker, defender);

            // Swap attacker and defender for the next turn
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        // Determine and print the winner of the match
        Player winner = playerA.isAlive() ? playerA : playerB;
        System.out.println("\nWinner: " + winner.getName() + " in " + rounds + " rounds.");
    }

    // Method to handle an attack between two players
    private void attack(Player attacker, Player defender) {
        int attackDamage = attacker.calculateAttackDamage();
        int defendStrength = defender.calculateDefendStrength();

        int damageTaken = Math.max(0, attackDamage - defendStrength);
        defender.receiveDamage(damageTaken); // Apply damage to the defending player

        System.out.println(attacker.getName() + " attacks " + defender.getName() + " with " + attackDamage + " damage.");
        System.out.println(defender.getName() + " defends with " + defendStrength + " strength.");
        System.out.println(defender.getName() + "'s Remaining Health: " + defender.getHealth());
    }
}

