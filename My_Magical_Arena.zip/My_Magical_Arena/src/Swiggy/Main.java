package Swiggy;

import java.util.Scanner;

public class Main {

    public static Player createPlayer(Scanner scanner, String name) {
        System.out.println("Enter " + name + "'s attributes (Health, Strength, Attack)");
        
        //** Get valid health input in range 1-100 **//
        int health = getValidInput(scanner, "Health (1-100)", 1, 100);  // Ask for health input from the user
        int strength = getValidInput(scanner, "Strength");  // Strength input
        int attack = getValidInput(scanner, "Attack");  // Attack input

        return new Player(health, strength, attack, name);  // Return a new Player object with user input
    }

    private static int getValidInput(Scanner scanner, String attribute) {
        int value;
        while (true) {
            System.out.print(attribute + ": ");
            value = scanner.nextInt();  // Get input from the user
            if (value > 0) {  // Validate that input is positive
                break;  // If valid, exit loop
            } else {
                System.out.println(attribute + " must be a positive number. Please try again.");
            }
        }
        return value;  // Return valid input
    }

    private static int getValidInput(Scanner scanner, String attribute, int min, int max) {
        int value;
        while (true) {
            System.out.print(attribute + ": ");
            value = scanner.nextInt();  // Get input from the user
            if (value >= min && value <= max) {  // Validate that input is within range
                break;  // If valid, exit loop
            } else {
                System.out.println(attribute + " must be between " + min + " and " + max + ". Please try again.");
            }
        }
        return value;  // Return valid input
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  // Create Scanner object for user input

        // Create Player A with health, strength, and attack attributes
        Player playerA = createPlayer(scanner, "Player A");
        // Create Player B with health, strength, and attack attributes
        Player playerB = createPlayer(scanner, "Player B");

        // Start the match between Player A and Player B
        Match match = new Match(playerA, playerB);
        match.start();  // Start the match

        scanner.close();  // Close the scanner after use
    }
}
